function bridgeConnectButton (connect){
    var btn = $("#bridge-connect-btn");
    btn.enable();
    if(connect){
        btn.html("Connect to Bridge");
        btn.addClass("btn-success").removeClass("btn-danger");
        $("#flight-gear-controls").hide();
        $("#flight-gear-parameter-controls").hide();
    } else {
        btn.html("Disconnect from Bridge");
        btn.removeClass("btn-success").addClass("btn-danger");
        $("#flight-gear-controls").show();
        $("#flight-gear-parameter-controls").show();
    }
}