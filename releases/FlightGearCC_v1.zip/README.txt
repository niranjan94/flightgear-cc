FlightGear Command Center:
==========================

This distribution package contains:

1) FlightGear Bridge Interface (FlightGear <-> Python)
2) FlightGear CC Interface (Python <-> User)

Prerequisites:
==============

The following package(s) have to be installed before running this program.

Microsoft Visual C++ 2008 Redistributable Package (published on 29-11-2007)
The Package can be downloaded at
https://goo.gl/Qz98SV (1.7 MB)

Usage Instructions:
===================

NOTE: DO NOT USE FLIGHTGEAR LAUNCHER TO LAUNCH FLIGHT GEAR. IF IT IS OPEN, CLOSE IT BEFORE PROCEEDING

1) Make sure the Prerequisite(s) are installed properly.
2) Turn off Windows Firewall (or) add an exception when asked
3) Double-click on FlightGearCC.exe 
4) If Firewall is on, you may need to add an exception when asked
5) Wait for the program to initialize
6) Follow onscreen instructions.
